<?php
require 'koneksi.php';

if (!isset($_SESSION['level'])) {
    header("Location: login.php");
} elseif ($_SESSION['level'] === 'admin') {
    header("Location: admin.php");
} else {
    header("Location: user.php");
}
exit;
?>