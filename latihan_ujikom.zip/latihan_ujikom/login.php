<?php
require 'koneksi.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $u = mysqli_real_escape_string($conn, $_POST['username']);
    $p = mysqli_real_escape_string($conn, $_POST['password']);
    $q = mysqli_query($conn, "SELECT * FROM user WHERE username='$u' AND password='$p' LIMIT 1");

    if ($d = mysqli_fetch_assoc($q)) {
        $_SESSION['id']    = $d['id'];
        $_SESSION['nama']  = $d['nama'];
        $_SESSION['level'] = $d['level'];
        header("Location: " . ($d['level'] === 'admin' ? "admin.php" : "user.php"));
        exit;
    }
    $err = "Username atau password salah!";
}
?>
<!DOCTYPE html>
<html>
<head><title>Login - Aplikasi Peminjaman Buku</title></head>
<body style="font-family:sans-serif; max-width:320px; margin:80px auto;">
    <h3>Login Peminjaman Buku</h3>
    <?php if (!empty($err)) echo "<p style='color:red'>$err</p>"; ?>
    <form method="POST">
        <label>Username</label><br>
        <input type="text" name="username" maxlength="20" required style="width:100%;margin-bottom:10px;padding:6px"><br>
        <label>Password</label><br>
        <input type="password" name="password" maxlength="20" required style="width:100%;margin-bottom:10px;padding:6px"><br>
        <button type="submit" style="width:100%;padding:8px">Login</button>
    </form>
</body>
</html>