<?php
session_start();
$conn = mysqli_connect("localhost", "root", "", "buku_db");
if (!$conn) {
    die("Koneksi database gagal: " . mysqli_connect_error());
}
?>